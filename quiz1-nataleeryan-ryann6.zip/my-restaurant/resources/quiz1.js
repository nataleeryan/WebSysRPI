$(document).ready(function() {

  $.getJSON("/my-restaurant/data/data.json", function(data) {
    for (var i = 0; i <data.dishes.length; i++){
      var tr = $('<tr/>');

      $(tr).append("<td>" + "<img src= '" + data.dishes[i].img + "' height='75'");
      $(tr).append("<td>" + data.dishes[i].name);
      $(tr).append("<td>" + data.dishes[i].desc);
      $(tr).append("<td>" + data.dishes[i].category);
      $(tr).append("<td>" + data.dishes[i].cuisine);
      $(tr).append("<td>" + data.dishes[i].ingredients);
      $(tr).append("<td>" + data.dishes[i].price);
      $('.table1').append(tr);

    }
  })

});
